package com.denvycom.seleniumtest;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Scraper {

	public static void main(String[] args) {
                WebDriver driver = new FirefoxDriver();
                // Change here
                driver.get("http://localhost/test.html");

                //Get the title of all posts
                List<WebElement> titles = driver.findElements(By.cssSelector("span.title"));
                
                // Get all spans
                List<WebElement> all_spans = driver.findElements(By.cssSelector("span"));
                System.out.println("Part a");
		for (int j = 0; j < titles.size(); j++) {
			if (j==3 || j==5)
                                System.out.println( titles.get(j).getText() ) ;
		}

                System.out.println("Part b");
                int counter = false;
                int count = 0;
                int[][] map = new int[5][2];
                for (int j=0; j< all_spans.size(); j++) {
                        if(count<=5) {
                                if(!counter) {
                                        map[i][0] = all_spans.get(j).getText();
                                        counter = true;
                                } else {
                                        map[i][1] = all_spans.get(j).getText();
                                        counter = false;
                                }
                        }
                }

                for (int j=0; j < 5; j++ ) {
                        System.out.println( map[j][0] + "\t - " + map[0][1] ) ;
                }              
                //Close the browser
                driver.quit();

	}

}
